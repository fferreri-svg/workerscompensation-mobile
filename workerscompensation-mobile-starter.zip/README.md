# WorkersCompensation.com Mobile

An Expo + React Native starter application for the WorkersCompensation.com mobile-first launch.

## Included in this first build

- Branded home screen with featured industry content
- Five-tab navigation: Home, News, Research, Learn, Account
- News feed and article detail screen
- Research landing screen with state/topic shortcuts
- Education landing screen
- Account screen UI
- Search field and saved-article interaction (local in-memory demo state)
- Responsive layouts and WorkersCompensation.com brand colors

## Requirements

- Node.js LTS
- npm
- Expo Go on an iOS or Android device, or an iOS Simulator / Android Emulator

## Run locally

```bash
npm install
npx expo start
```

Scan the QR code with Expo Go, or press `i` / `a` for a simulator/emulator.

## Important implementation notes

This is a working front-end starter with sample content. It is not yet connected to a production CMS, authentication provider, database, push notification service, or payment processor. The sample articles and research entries are placeholders and must not be treated as legal advice or authoritative legal research.

Before publishing:
1. Confirm the final brand assets and legal entity details.
2. Connect a secure backend and CMS.
3. Implement real authentication and account recovery.
4. Replace sample content with licensed/verified content.
5. Add privacy policy, terms, analytics consent, and App Store disclosures.
6. Configure production bundle identifiers, signing, and store assets.

## Suggested next backend milestone

Build a content API that supports:
- `GET /api/articles`
- `GET /api/articles/:slug`
- `GET /api/categories`
- `GET /api/research/states`
- `POST /api/auth/...`

Keep credentials and API secrets out of the mobile app. Use a server-side API for privileged operations.
