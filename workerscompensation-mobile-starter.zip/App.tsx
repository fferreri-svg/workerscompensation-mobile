import React, { useMemo, useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  StatusBar,
  Image,
  Platform,
} from "react-native";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";
import { Ionicons } from "@expo/vector-icons";

const COLORS = {
  navy: "#153B68",
  navyDark: "#0E2B4D",
  gold: "#D5A52A",
  red: "#B52B32",
  ink: "#172536",
  muted: "#667487",
  line: "#E4E9EF",
  paper: "#F4F7FA",
  white: "#FFFFFF",
  paleGold: "#FFF7E4",
  paleBlue: "#EAF1F8",
};

type Tab = "Home" | "News" | "Research" | "Learn" | "Account";

type Article = {
  id: string;
  category: string;
  title: string;
  summary: string;
  date: string;
  readTime: string;
  featured?: boolean;
};

const ARTICLES: Article[] = [
  {
    id: "1",
    category: "INDUSTRY NEWS",
    title: "The latest developments shaping workers' compensation",
    summary:
      "A daily briefing on the people, policies, technology, and trends influencing the workers' compensation community.",
    date: "Today's briefing",
    readTime: "5 min read",
    featured: true,
  },
  {
    id: "2",
    category: "CLAIMS & RISK",
    title: "Building better outcomes through thoughtful claims management",
    summary:
      "Explore practical approaches to communication, coordination, and supporting injured workers throughout recovery.",
    date: "Industry perspective",
    readTime: "4 min read",
  },
  {
    id: "3",
    category: "WORKFORCE & WELLBEING",
    title: "Why the human side of claims matters",
    summary:
      "A closer look at trust, empathy, and the everyday interactions that can shape the claim experience.",
    date: "Featured insight",
    readTime: "6 min read",
  },
];

const RESEARCH_AREAS = [
  { icon: "map-outline", title: "State-by-state resources", subtitle: "Explore jurisdiction-specific information" },
  { icon: "document-text-outline", title: "Statutes & regulations", subtitle: "Find laws and regulatory resources" },
  { icon: "scale-outline", title: "Case law", subtitle: "Research judicial decisions and topics" },
  { icon: "search-outline", title: "Research topics", subtitle: "Browse common workers' comp subjects" },
];

function BrandMark() {
  return (
    <View style={styles.brandRow}>
      <View style={styles.brandIcon}>
        <Ionicons name="shield-checkmark" size={23} color={COLORS.gold} />
      </View>
      <View>
        <Text style={styles.brandName}>WorkersCompensation.com</Text>
        <Text style={styles.brandTagline}>YOUR INDUSTRY. YOUR RESOURCE.</Text>
      </View>
    </View>
  );
}

function SectionHeading({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return (
    <View style={styles.sectionHeading}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {action ? <TouchableOpacity onPress={onAction}><Text style={styles.textLink}>{action}</Text></TouchableOpacity> : null}
    </View>
  );
}

function ArticleCard({ article, onPress, compact = false }: { article: Article; onPress: () => void; compact?: boolean }) {
  return (
    <TouchableOpacity activeOpacity={0.85} onPress={onPress} style={[styles.articleCard, compact && styles.articleCardCompact]}>
      <View style={styles.articleImage}>
        <View style={styles.imageAccent} />
        <Ionicons name="newspaper-outline" size={34} color={COLORS.white} />
        <Text style={styles.imageLabel}>WORKERS' COMPENSATION</Text>
      </View>
      <View style={styles.articleBody}>
        <Text style={styles.eyebrow}>{article.category}</Text>
        <Text style={styles.articleTitle}>{article.title}</Text>
        {!compact ? <Text style={styles.articleSummary}>{article.summary}</Text> : null}
        <View style={styles.articleMeta}>
          <Text style={styles.metaText}>{article.date}</Text>
          <Text style={styles.metaDot}>•</Text>
          <Text style={styles.metaText}>{article.readTime}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

function HomeScreen({ onOpenArticle, onNavigate }: { onOpenArticle: (a: Article) => void; onNavigate: (tab: Tab) => void }) {
  const [query, setQuery] = useState("");
  const featured = ARTICLES[0];
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.screenContent} showsVerticalScrollIndicator={false}>
      <View style={styles.hero}>
        <BrandMark />
        <View style={styles.heroCopy}>
          <Text style={styles.heroKicker}>THE WORKERS' COMPENSATION COMMUNITY</Text>
          <Text style={styles.heroTitle}>Knowledge that moves the industry forward.</Text>
          <Text style={styles.heroSubtitle}>News, research, education, and resources for the people who make a difference.</Text>
        </View>
        <View style={styles.searchBox}>
          <Ionicons name="search" size={19} color={COLORS.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search news, topics, and resources"
            placeholderTextColor="#8A96A5"
            style={styles.searchInput}
            returnKeyType="search"
            onSubmitEditing={() => onNavigate("News")}
          />
          {query.length > 0 ? <TouchableOpacity onPress={() => setQuery("")}><Ionicons name="close-circle" size={18} color={COLORS.muted} /></TouchableOpacity> : null}
        </View>
        <View style={styles.heroStripe} />
      </View>

      <View style={styles.contentSection}>
        <View style={styles.featuredLabel}><View style={styles.redDash} /><Text style={styles.eyebrow}>FEATURED</Text></View>
        <TouchableOpacity activeOpacity={0.9} onPress={() => onOpenArticle(featured)} style={styles.featureCard}>
          <View style={styles.featureVisual}>
            <View style={styles.featureCircle} />
            <Ionicons name="people-outline" size={58} color="#FFFFFF" />
            <Text style={styles.featureVisualText}>INSIGHT • CONNECTION • IMPACT</Text>
          </View>
          <View style={styles.featureText}>
            <Text style={styles.featureTitle}>{featured.title}</Text>
            <Text style={styles.articleSummary}>{featured.summary}</Text>
            <Text style={styles.readMore}>READ THE STORY  <Ionicons name="arrow-forward" size={13} color={COLORS.navy} /></Text>
          </View>
        </TouchableOpacity>

        <SectionHeading title="Explore the platform" />
        <View style={styles.quickGrid}>
          {[
            { icon: "newspaper-outline", title: "Industry News", tab: "News" as Tab, color: COLORS.navy },
            { icon: "scale-outline", title: "Legal Research", tab: "Research" as Tab, color: COLORS.red },
            { icon: "book-outline", title: "Simply Research", tab: "Research" as Tab, color: "#A47712" },
            { icon: "school-outline", title: "Education", tab: "Learn" as Tab, color: COLORS.navy },
          ].map((item) => (
            <TouchableOpacity key={item.title} style={styles.quickCard} onPress={() => onNavigate(item.tab)}>
              <Ionicons name={item.icon as any} size={25} color={item.color} />
              <Text style={styles.quickTitle}>{item.title}</Text>
              <Ionicons name="arrow-forward" size={14} color={COLORS.muted} />
            </TouchableOpacity>
          ))}
        </View>

        <SectionHeading title="Latest from the industry" action="View all" onAction={() => onNavigate("News")} />
        {ARTICLES.slice(1).map((article) => <ArticleCard key={article.id} article={article} compact onPress={() => onOpenArticle(article)} />)}
        <View style={styles.bottomNote}>
          <Text style={styles.bottomNoteTitle}>A resource for the entire community.</Text>
          <Text style={styles.bottomNoteText}>Connecting the people, ideas, and information shaping workers' compensation.</Text>
        </View>
      </View>
    </ScrollView>
  );
}

function NewsScreen({ onOpenArticle }: { onOpenArticle: (a: Article) => void }) {
  const [filter, setFilter] = useState("All");
  const filters = ["All", "Claims", "Legal", "Workforce"];
  const filtered = useMemo(() => filter === "All" ? ARTICLES : ARTICLES.filter(a => (a.category + a.title).toLowerCase().includes(filter.toLowerCase())), [filter]);
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.screenContent}>
      <View style={styles.pageHeader}>
        <Text style={styles.pageEyebrow}>STAY INFORMED</Text>
        <Text style={styles.pageTitle}>Industry News</Text>
        <Text style={styles.pageSubtitle}>The latest stories, perspectives, and developments from across workers' compensation.</Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
        {filters.map(f => <TouchableOpacity key={f} onPress={() => setFilter(f)} style={[styles.filterChip, filter === f && styles.filterChipActive]}><Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f}</Text></TouchableOpacity>)}
      </ScrollView>
      <View style={styles.contentSection}>
        {filtered.length ? filtered.map(a => <ArticleCard key={a.id} article={a} onPress={() => onOpenArticle(a)} />) : <Text style={styles.emptyText}>No sample stories in this category yet.</Text>}
        <Text style={styles.disclaimer}>Sample content shown for the initial app build. Live editorial content will be connected in a later phase.</Text>
      </View>
    </ScrollView>
  );
}

function ResearchScreen() {
  const [search, setSearch] = useState("");
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.screenContent}>
      <View style={[styles.pageHeader, styles.researchHeader]}>
        <Text style={styles.pageEyebrow}>SIMPLY RESEARCH</Text>
        <Text style={[styles.pageTitle, { color: COLORS.white }]}>Find the information you need.</Text>
        <Text style={[styles.pageSubtitle, { color: "#D9E3EF" }]}>A starting point for workers' compensation legal and industry research.</Text>
        <View style={styles.searchBox}>
          <Ionicons name="search" size={19} color={COLORS.muted} />
          <TextInput value={search} onChangeText={setSearch} placeholder="Search states, laws, topics..." placeholderTextColor="#8A96A5" style={styles.searchInput} />
        </View>
      </View>
      <View style={styles.contentSection}>
        <SectionHeading title="Research library" />
        {RESEARCH_AREAS.filter(x => (x.title + x.subtitle).toLowerCase().includes(search.toLowerCase())).map(item => (
          <TouchableOpacity key={item.title} style={styles.resourceRow} onPress={() => {}}>
            <View style={styles.resourceIcon}><Ionicons name={item.icon as any} size={23} color={COLORS.navy} /></View>
            <View style={styles.resourceCopy}><Text style={styles.resourceTitle}>{item.title}</Text><Text style={styles.resourceSubtitle}>{item.subtitle}</Text></View>
            <Ionicons name="chevron-forward" size={19} color={COLORS.muted} />
          </TouchableOpacity>
        ))}
        <View style={styles.noticeCard}>
          <Ionicons name="information-circle-outline" size={20} color={COLORS.red} />
          <Text style={styles.noticeText}>Research content is not yet connected. Legal materials will need jurisdiction-specific verification and source citations before publication.</Text>
        </View>
      </View>
    </ScrollView>
  );
}

function LearnScreen() {
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.screenContent}>
      <View style={styles.pageHeader}>
        <Text style={styles.pageEyebrow}>GROW YOUR KNOWLEDGE</Text>
        <Text style={styles.pageTitle}>Education Center</Text>
        <Text style={styles.pageSubtitle}>Learning opportunities and professional development for the workers' compensation community.</Text>
      </View>
      <View style={styles.contentSection}>
        <View style={styles.learnBanner}>
          <Ionicons name="school-outline" size={42} color={COLORS.gold} />
          <Text style={styles.learnBannerTitle}>Learn. Connect. Advance.</Text>
          <Text style={styles.learnBannerText}>Discover webinars, courses, presentations, and practical resources.</Text>
        </View>
        {[
          { icon: "videocam-outline", title: "Webinars & events", desc: "Upcoming sessions and recorded programs" },
          { icon: "play-circle-outline", title: "On-demand learning", desc: "Watch educational content on your schedule" },
          { icon: "ribbon-outline", title: "Professional development", desc: "Resources to support continuing education" },
        ].map(x => <TouchableOpacity key={x.title} style={styles.resourceRow}><View style={styles.resourceIcon}><Ionicons name={x.icon as any} size={23} color={COLORS.navy} /></View><View style={styles.resourceCopy}><Text style={styles.resourceTitle}>{x.title}</Text><Text style={styles.resourceSubtitle}>{x.desc}</Text></View><Ionicons name="chevron-forward" size={19} color={COLORS.muted} /></TouchableOpacity>)}
        <Text style={styles.disclaimer}>Courses, registrations, and certificates will be enabled in a future release.</Text>
      </View>
    </ScrollView>
  );
}

function AccountScreen() {
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.screenContent}>
      <View style={styles.pageHeader}>
        <Text style={styles.pageEyebrow}>YOUR WORKSPACE</Text>
        <Text style={styles.pageTitle}>Your Account</Text>
        <Text style={styles.pageSubtitle}>Sign in to personalize your WorkersCompensation.com experience.</Text>
      </View>
      <View style={styles.contentSection}>
        <View style={styles.accountCard}>
          <View style={styles.avatar}><Ionicons name="person-outline" size={30} color={COLORS.navy} /></View>
          <Text style={styles.accountTitle}>Welcome to the community</Text>
          <Text style={styles.accountText}>Account registration and sign-in will be connected to the secure platform backend.</Text>
          <TouchableOpacity style={styles.primaryButton}><Text style={styles.primaryButtonText}>Sign in</Text></TouchableOpacity>
          <TouchableOpacity style={styles.secondaryButton}><Text style={styles.secondaryButtonText}>Create an account</Text></TouchableOpacity>
        </View>
        {["Saved articles", "Notification preferences", "Subscriptions", "Help & support", "Privacy policy", "Terms of use"].map((x, i) => (
          <TouchableOpacity key={x} style={styles.accountRow}><Text style={styles.resourceTitle}>{x}</Text><Ionicons name="chevron-forward" size={18} color={COLORS.muted} /></TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

function ArticleDetail({ article, onBack, saved, onToggleSave }: { article: Article; onBack: () => void; saved: boolean; onToggleSave: () => void }) {
  return (
    <SafeAreaView style={styles.detailSafe}>
      <View style={styles.detailTop}>
        <TouchableOpacity onPress={onBack} style={styles.backButton}><Ionicons name="arrow-back" size={22} color={COLORS.navy} /></TouchableOpacity>
        <Text style={styles.detailTopLabel}>ARTICLE</Text>
        <TouchableOpacity onPress={onToggleSave} style={styles.backButton}><Ionicons name={saved ? "bookmark" : "bookmark-outline"} size={21} color={COLORS.navy} /></TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={styles.detailContent}>
        <View style={styles.detailHero}>
          <Ionicons name="newspaper-outline" size={48} color={COLORS.white} />
          <Text style={styles.detailHeroLabel}>WORKERS' COMPENSATION</Text>
        </View>
        <Text style={styles.eyebrow}>{article.category}</Text>
        <Text style={styles.detailTitle}>{article.title}</Text>
        <Text style={styles.metaText}>{article.date}  •  {article.readTime}</Text>
        <View style={styles.redRule} />
        <Text style={styles.detailParagraph}>{article.summary}</Text>
        <Text style={styles.detailParagraph}>Workers' compensation is shaped by the decisions, experiences, and collaboration of people across the industry. This sample article layout demonstrates how editorial content will appear in the mobile application.</Text>
        <View style={styles.noticeCard}><Ionicons name="information-circle-outline" size={20} color={COLORS.red} /><Text style={styles.noticeText}>Demonstration article. This is placeholder copy, not a published news report or legal guidance.</Text></View>
      </ScrollView>
    </SafeAreaView>
  );
}

const TAB_ITEMS: { key: Tab; icon: keyof typeof Ionicons.glyphMap; label: string }[] = [
  { key: "Home", icon: "home-outline", label: "Home" },
  { key: "News", icon: "newspaper-outline", label: "News" },
  { key: "Research", icon: "search-outline", label: "Research" },
  { key: "Learn", icon: "school-outline", label: "Learn" },
  { key: "Account", icon: "person-circle-outline", label: "Account" },
];

export default function App() {
  const [tab, setTab] = useState<Tab>("Home");
  const [activeArticle, setActiveArticle] = useState<Article | null>(null);
  const [saved, setSaved] = useState<string[]>([]);

  const toggleSave = (id: string) => setSaved(current => current.includes(id) ? current.filter(x => x !== id) : [...current, id]);

  if (activeArticle) {
    return <ArticleDetail article={activeArticle} onBack={() => setActiveArticle(null)} saved={saved.includes(activeArticle.id)} onToggleSave={() => toggleSave(activeArticle.id)} />;
  }

  const renderScreen = () => {
    switch (tab) {
      case "News": return <NewsScreen onOpenArticle={setActiveArticle} />;
      case "Research": return <ResearchScreen />;
      case "Learn": return <LearnScreen />;
      case "Account": return <AccountScreen />;
      default: return <HomeScreen onOpenArticle={setActiveArticle} onNavigate={setTab} />;
    }
  };

  return (
    <SafeAreaView style={styles.appSafe}>
      <ExpoStatusBar style="light" backgroundColor={COLORS.navyDark} />
      {renderScreen()}
      <View style={styles.tabBar}>
        {TAB_ITEMS.map(item => {
          const active = tab === item.key;
          return (
            <TouchableOpacity key={item.key} onPress={() => setTab(item.key)} style={styles.tabItem} accessibilityRole="button" accessibilityLabel={item.label}>
              <Ionicons name={active ? item.icon.replace("-outline", "") as any : item.icon} size={22} color={active ? COLORS.navy : "#8995A3"} />
              <Text style={[styles.tabLabel, active && styles.tabLabelActive]}>{item.label}</Text>
              {active ? <View style={styles.tabIndicator} /> : <View style={styles.tabIndicatorPlaceholder} />}
            </TouchableOpacity>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  appSafe: { flex: 1, backgroundColor: COLORS.paper, paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0 },
  screen: { flex: 1, backgroundColor: COLORS.paper },
  screenContent: { paddingBottom: 22 },
  hero: { backgroundColor: COLORS.navy, paddingHorizontal: 20, paddingTop: 15, paddingBottom: 27, overflow: "hidden" },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  brandIcon: { width: 39, height: 39, borderRadius: 12, backgroundColor: COLORS.navyDark, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#456487" },
  brandName: { color: COLORS.white, fontSize: 16, fontWeight: "800", letterSpacing: -0.3 },
  brandTagline: { color: COLORS.gold, fontSize: 9, fontWeight: "800", letterSpacing: 1.2, marginTop: 2 },
  heroCopy: { marginTop: 30, maxWidth: 340 },
  heroKicker: { color: COLORS.gold, fontSize: 10, fontWeight: "800", letterSpacing: 1.3 },
  heroTitle: { color: COLORS.white, fontSize: 30, lineHeight: 36, fontWeight: "800", marginTop: 10, letterSpacing: -0.7 },
  heroSubtitle: { color: "#D7E1EC", fontSize: 14, lineHeight: 21, marginTop: 10 },
  searchBox: { backgroundColor: COLORS.white, borderRadius: 12, paddingHorizontal: 13, height: 49, flexDirection: "row", alignItems: "center", gap: 9, marginTop: 22 },
  searchInput: { flex: 1, color: COLORS.ink, fontSize: 13, paddingVertical: 0 },
  heroStripe: { position: "absolute", height: 5, backgroundColor: COLORS.gold, bottom: 0, left: 0, right: 0 },
  contentSection: { paddingHorizontal: 18, paddingTop: 22 },
  featuredLabel: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 11 },
  redDash: { width: 19, height: 3, backgroundColor: COLORS.red, borderRadius: 2 },
  eyebrow: { color: COLORS.red, fontSize: 10, fontWeight: "800", letterSpacing: 1.1 },
  featureCard: { backgroundColor: COLORS.white, borderRadius: 17, overflow: "hidden", borderWidth: 1, borderColor: COLORS.line, marginBottom: 25 },
  featureVisual: { height: 154, backgroundColor: COLORS.navyDark, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  featureCircle: { position: "absolute", width: 220, height: 220, borderRadius: 110, borderWidth: 1, borderColor: "#456487", right: -35, top: -75 },
  featureVisualText: { color: COLORS.gold, fontSize: 9, fontWeight: "800", letterSpacing: 1.3, marginTop: 12 },
  featureText: { padding: 16 },
  featureTitle: { color: COLORS.ink, fontSize: 19, lineHeight: 25, fontWeight: "800" },
  articleSummary: { color: COLORS.muted, fontSize: 13, lineHeight: 20, marginTop: 8 },
  readMore: { color: COLORS.navy, fontSize: 10, fontWeight: "800", letterSpacing: 0.7, marginTop: 15 },
  sectionHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 13, marginTop: 5 },
  sectionTitle: { color: COLORS.ink, fontSize: 18, fontWeight: "800", letterSpacing: -0.3 },
  textLink: { color: COLORS.navy, fontSize: 12, fontWeight: "700" },
  quickGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", marginBottom: 23 },
  quickCard: { width: "48.3%", minHeight: 102, backgroundColor: COLORS.white, borderRadius: 13, borderWidth: 1, borderColor: COLORS.line, padding: 13, marginBottom: 10, justifyContent: "space-between" },
  quickTitle: { color: COLORS.ink, fontWeight: "700", fontSize: 12, marginTop: 8 },
  articleCard: { backgroundColor: COLORS.white, borderRadius: 15, borderWidth: 1, borderColor: COLORS.line, overflow: "hidden", marginBottom: 14 },
  articleCardCompact: { flexDirection: "row", minHeight: 124 },
  articleImage: { height: 142, backgroundColor: COLORS.navy, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  imageAccent: { position: "absolute", width: 180, height: 180, borderWidth: 1, borderColor: "#52708E", borderRadius: 90, right: -35, top: -90 },
  imageLabel: { color: COLORS.gold, fontSize: 8, fontWeight: "800", letterSpacing: 1, marginTop: 8 },
  articleBody: { padding: 14, flex: 1 },
  articleTitle: { color: COLORS.ink, fontSize: 16, fontWeight: "800", lineHeight: 21, marginTop: 6 },
  articleMeta: { flexDirection: "row", alignItems: "center", marginTop: 11, gap: 7 },
  metaText: { color: COLORS.muted, fontSize: 10 },
  metaDot: { color: COLORS.gold, fontSize: 11 },
  bottomNote: { backgroundColor: COLORS.paleGold, borderRadius: 14, padding: 17, marginTop: 10, marginBottom: 8, borderLeftWidth: 3, borderLeftColor: COLORS.gold },
  bottomNoteTitle: { color: COLORS.navy, fontSize: 15, fontWeight: "800" },
  bottomNoteText: { color: COLORS.muted, fontSize: 12, lineHeight: 18, marginTop: 5 },
  pageHeader: { backgroundColor: COLORS.white, paddingHorizontal: 20, paddingTop: 26, paddingBottom: 22, borderBottomWidth: 1, borderBottomColor: COLORS.line },
  pageEyebrow: { color: COLORS.red, fontSize: 10, fontWeight: "800", letterSpacing: 1.4 },
  pageTitle: { color: COLORS.navy, fontSize: 29, fontWeight: "800", letterSpacing: -0.6, marginTop: 8 },
  pageSubtitle: { color: COLORS.muted, fontSize: 14, lineHeight: 21, marginTop: 8 },
  filterRow: { paddingHorizontal: 18, paddingVertical: 15, gap: 8 },
  filterChip: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: 30, borderWidth: 1, borderColor: COLORS.line, backgroundColor: COLORS.white },
  filterChipActive: { backgroundColor: COLORS.navy, borderColor: COLORS.navy },
  filterText: { color: COLORS.muted, fontWeight: "700", fontSize: 11 },
  filterTextActive: { color: COLORS.white },
  emptyText: { color: COLORS.muted, textAlign: "center", padding: 25 },
  disclaimer: { color: COLORS.muted, fontSize: 11, lineHeight: 17, marginTop: 8, marginBottom: 18 },
  researchHeader: { backgroundColor: COLORS.navy, borderBottomWidth: 0 },
  resourceRow: { flexDirection: "row", alignItems: "center", backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.line, borderRadius: 13, padding: 13, marginBottom: 10, gap: 12 },
  resourceIcon: { width: 43, height: 43, borderRadius: 12, backgroundColor: COLORS.paleBlue, alignItems: "center", justifyContent: "center" },
  resourceCopy: { flex: 1 },
  resourceTitle: { color: COLORS.ink, fontSize: 13, fontWeight: "800" },
  resourceSubtitle: { color: COLORS.muted, fontSize: 11, lineHeight: 16, marginTop: 3 },
  noticeCard: { flexDirection: "row", alignItems: "flex-start", gap: 9, backgroundColor: "#FFF4F2", borderRadius: 12, padding: 13, marginTop: 8 },
  noticeText: { flex: 1, color: "#74464A", fontSize: 11, lineHeight: 17 },
  learnBanner: { backgroundColor: COLORS.navy, borderRadius: 16, padding: 20, alignItems: "flex-start", marginBottom: 17 },
  learnBannerTitle: { color: COLORS.white, fontSize: 21, fontWeight: "800", marginTop: 13 },
  learnBannerText: { color: "#D7E1EC", fontSize: 13, lineHeight: 19, marginTop: 6 },
  accountCard: { backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.line, borderRadius: 16, padding: 20, alignItems: "center", marginBottom: 17 },
  avatar: { width: 62, height: 62, borderRadius: 31, backgroundColor: COLORS.paleBlue, alignItems: "center", justifyContent: "center" },
  accountTitle: { color: COLORS.ink, fontSize: 18, fontWeight: "800", marginTop: 13 },
  accountText: { color: COLORS.muted, fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 7 },
  primaryButton: { backgroundColor: COLORS.navy, borderRadius: 10, paddingVertical: 13, alignItems: "center", width: "100%", marginTop: 17 },
  primaryButtonText: { color: COLORS.white, fontWeight: "800", fontSize: 13 },
  secondaryButton: { borderWidth: 1, borderColor: COLORS.navy, borderRadius: 10, paddingVertical: 12, alignItems: "center", width: "100%", marginTop: 9 },
  secondaryButtonText: { color: COLORS.navy, fontWeight: "800", fontSize: 13 },
  accountRow: { backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.line, borderRadius: 11, padding: 15, marginBottom: 8, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  tabBar: { height: 66, backgroundColor: COLORS.white, borderTopWidth: 1, borderTopColor: COLORS.line, flexDirection: "row", justifyContent: "space-around", alignItems: "center", paddingBottom: 3 },
  tabItem: { flex: 1, alignItems: "center", justifyContent: "center", height: 62, gap: 3 },
  tabLabel: { color: "#8995A3", fontSize: 9, fontWeight: "600" },
  tabLabelActive: { color: COLORS.navy, fontWeight: "800" },
  tabIndicator: { width: 17, height: 3, borderRadius: 2, backgroundColor: COLORS.gold, marginTop: 1 },
  tabIndicatorPlaceholder: { width: 17, height: 3, marginTop: 1 },
  detailSafe: { flex: 1, backgroundColor: COLORS.white, paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0 },
  detailTop: { height: 54, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 17, borderBottomWidth: 1, borderBottomColor: COLORS.line },
  backButton: { width: 38, height: 38, alignItems: "center", justifyContent: "center" },
  detailTopLabel: { color: COLORS.muted, fontSize: 10, fontWeight: "800", letterSpacing: 1.4 },
  detailContent: { padding: 20, paddingBottom: 40 },
  detailHero: { height: 190, borderRadius: 16, backgroundColor: COLORS.navy, alignItems: "center", justifyContent: "center", marginBottom: 22 },
  detailHeroLabel: { color: COLORS.gold, fontSize: 9, fontWeight: "800", letterSpacing: 1.4, marginTop: 12 },
  detailTitle: { color: COLORS.ink, fontSize: 27, lineHeight: 34, fontWeight: "800", marginTop: 8, marginBottom: 10 },
  redRule: { width: 45, height: 3, backgroundColor: COLORS.red, marginVertical: 20, borderRadius: 2 },
  detailParagraph: { color: "#455365", fontSize: 15, lineHeight: 25, marginBottom: 15 },
});
